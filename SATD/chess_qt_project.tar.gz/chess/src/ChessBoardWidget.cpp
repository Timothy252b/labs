#include "ChessBoardWidget.h"

#include <QPainter>
#include <QPen>
#include <QBrush>
#include <QRadialGradient>
#include <QMouseEvent>
#include <QResizeEvent>
#include <QFontMetrics>
#include <QFont>
#include <QDir>
#include <QCoreApplication>
#include <QMessageBox>
#include <QInputDialog>
#include <QStringList>
#include <algorithm>

using namespace chess;

namespace {

// Юникод-символы фигур — используются как запасной вариант, если картинки не найдены
QString unicodeForPiece(const Piece& p) {
    if (p.isEmpty()) return QString();
    if (p.color == Color::White) {
        switch (p.type) {
            case PieceType::Pawn:   return QStringLiteral("\u2659");
            case PieceType::Knight: return QStringLiteral("\u2658");
            case PieceType::Bishop: return QStringLiteral("\u2657");
            case PieceType::Rook:   return QStringLiteral("\u2656");
            case PieceType::Queen:  return QStringLiteral("\u2655");
            case PieceType::King:   return QStringLiteral("\u2654");
            default: return QString();
        }
    } else {
        switch (p.type) {
            case PieceType::Pawn:   return QStringLiteral("\u265F");
            case PieceType::Knight: return QStringLiteral("\u265E");
            case PieceType::Bishop: return QStringLiteral("\u265D");
            case PieceType::Rook:   return QStringLiteral("\u265C");
            case PieceType::Queen:  return QStringLiteral("\u265B");
            case PieceType::King:   return QStringLiteral("\u265A");
            default: return QString();
        }
    }
}

QString pieceTypeName(PieceType t) {
    switch (t) {
        case PieceType::Pawn:   return QStringLiteral("pawn");
        case PieceType::Knight: return QStringLiteral("knight");
        case PieceType::Bishop: return QStringLiteral("bishop");
        case PieceType::Rook:   return QStringLiteral("rook");
        case PieceType::Queen:  return QStringLiteral("queen");
        case PieceType::King:   return QStringLiteral("king");
        default: return QString();
    }
}

} // namespace

ChessBoardWidget::ChessBoardWidget(QWidget* parent) : QWidget(parent) {
    setMouseTracking(false);
    setMinimumSize(320, 320);
    loadPieceImages();
    recomputeGeometry();
}

QSize ChessBoardWidget::sizeHint() const {
    return QSize(640, 640);
}

// ----------------------------------------------------------------------
// Загрузка картинок фигур
// ----------------------------------------------------------------------

void ChessBoardWidget::loadPieceImages() {
    // Ищем картинки в нескольких разумных местах, чтобы было проще подключить
    // свои файлы независимо от того, как и откуда запущено приложение.
    QStringList searchDirs = {
        QStringLiteral(":/pieces"),                       // если подключите через .qrc
        QStringLiteral("resources/pieces"),
        QStringLiteral("../resources/pieces"),
        QStringLiteral("./pieces"),
        QCoreApplication::applicationDirPath() + "/resources/pieces",
        QCoreApplication::applicationDirPath() + "/pieces",
    };

    static const QStringList colors = {"white", "black"};
    static const QStringList types  = {"pawn", "knight", "bishop", "rook", "queen", "king"};
    static const QStringList exts   = {"png", "svg", "jpg", "jpeg"};

    int loadedCount = 0;
    for (const QString& color : colors) {
        for (const QString& type : types) {
            QString key = color + "_" + type;
            bool found = false;
            for (const QString& dir : searchDirs) {
                for (const QString& ext : exts) {
                    QString path = dir + "/" + key + "." + ext;
                    QPixmap pix(path);
                    if (!pix.isNull()) {
                        pieceImages_[key] = pix;
                        found = true;
                        loadedCount++;
                        break;
                    }
                }
                if (found) break;
            }
        }
    }
    imagesLoaded_ = (loadedCount == colors.size() * types.size());
    // Если не все 12 картинок найдены — не страшно: для отсутствующих
    // фигур будет автоматически использован символьный запасной вариант.
}

QString ChessBoardWidget::pieceImageKey(const Piece& p) const {
    if (p.isEmpty()) return QString();
    QString color = (p.color == Color::White) ? "white" : "black";
    return color + "_" + pieceTypeName(p.type);
}

// ----------------------------------------------------------------------
// Геометрия доски
// ----------------------------------------------------------------------

void ChessBoardWidget::recomputeGeometry() {
    int side = std::min(width(), height());
    squareSize_ = std::max(1, side / 8);
    int boardPixelSize = squareSize_ * 8;
    boardOriginX_ = (width() - boardPixelSize) / 2;
    boardOriginY_ = (height() - boardPixelSize) / 2;
}

void ChessBoardWidget::resizeEvent(QResizeEvent* event) {
    QWidget::resizeEvent(event);
    recomputeGeometry();
}

// Преобразование file/rank в визуальную колонку/строку с учётом флипа доски.
// visCol 0..7 слева-направо на экране, visRow 0..7 сверху-вниз на экране.
static void squareToVisual(Square sq, bool flipped, int& visCol, int& visRow) {
    if (!flipped) {
        visCol = sq.file;
        visRow = 7 - sq.rank;
    } else {
        visCol = 7 - sq.file;
        visRow = sq.rank;
    }
}

static Square visualToSquare(int visCol, int visRow, bool flipped) {
    if (!flipped) {
        return Square(visCol, 7 - visRow);
    } else {
        return Square(7 - visCol, visRow);
    }
}

QPoint ChessBoardWidget::squareTopLeft(Square sq) const {
    int visCol, visRow;
    squareToVisual(sq, flipped_, visCol, visRow);
    return QPoint(boardOriginX_ + visCol * squareSize_, boardOriginY_ + visRow * squareSize_);
}

QRect ChessBoardWidget::squareRect(Square sq) const {
    QPoint tl = squareTopLeft(sq);
    return QRect(tl.x(), tl.y(), squareSize_, squareSize_);
}

Square ChessBoardWidget::widgetPosToSquare(QPoint pos) const {
    int x = pos.x() - boardOriginX_;
    int y = pos.y() - boardOriginY_;
    if (x < 0 || y < 0) return Square();
    int visCol = x / squareSize_;
    int visRow = y / squareSize_;
    if (visCol < 0 || visCol > 7 || visRow < 0 || visRow > 7) return Square();
    return visualToSquare(visCol, visRow, flipped_);
}

// ----------------------------------------------------------------------
// Отрисовка
// ----------------------------------------------------------------------

void ChessBoardWidget::paintEvent(QPaintEvent* /*event*/) {
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    painter.setRenderHint(QPainter::SmoothPixmapTransform, true);

    painter.fillRect(rect(), palette().window());

    drawBoardSquares(painter);
    drawHighlights(painter);
    drawCoordinates(painter);
    drawPieces(painter);
}

void ChessBoardWidget::drawBoardSquares(QPainter& painter) {
    const QColor light(240, 217, 181);
    const QColor dark(181, 136, 99);

    for (int f = 0; f < 8; ++f) {
        for (int r = 0; r < 8; ++r) {
            Square sq(f, r);
            QRect rc = squareRect(sq);
            bool isLight = ((f + r) % 2 == 1);
            painter.fillRect(rc, isLight ? light : dark);
        }
    }
}

void ChessBoardWidget::drawCoordinates(QPainter& painter) {
    QFont font = painter.font();
    font.setPointSize(std::max(8, squareSize_ / 7));
    painter.setFont(font);

    for (int f = 0; f < 8; ++f) {
        Square bottomSq = flipped_ ? Square(f, 7) : Square(f, 0);
        QRect rc = squareRect(bottomSq);
        QString label = QString(QChar('a' + f));
        QColor col = ((bottomSq.file + bottomSq.rank) % 2 == 1) ? QColor(181,136,99) : QColor(240,217,181);
        painter.setPen(col);
        painter.drawText(QRect(rc.left() + 3, rc.bottom() - squareSize_/4, squareSize_/2, squareSize_/4),
                          Qt::AlignLeft | Qt::AlignVCenter, label);
    }
    for (int r = 0; r < 8; ++r) {
        Square leftSq = flipped_ ? Square(7, r) : Square(0, r);
        QRect rc = squareRect(leftSq);
        QString label = QString::number(r + 1);
        QColor col = ((leftSq.file + leftSq.rank) % 2 == 1) ? QColor(181,136,99) : QColor(240,217,181);
        painter.setPen(col);
        painter.drawText(QRect(rc.left() + 3, rc.top() + 2, squareSize_/2, squareSize_/4),
                          Qt::AlignLeft | Qt::AlignVCenter, label);
    }
}

void ChessBoardWidget::drawHighlights(QPainter& painter) {
    // Подсветка последнего хода
    if (lastMove_) {
        QColor lastMoveColor(170, 200, 100, 130);
        painter.fillRect(squareRect(lastMove_->from), lastMoveColor);
        painter.fillRect(squareRect(lastMove_->to), lastMoveColor);
    }

    // Подсветка выбранной фигуры
    if (selected_) {
        QColor selColor(100, 160, 220, 150);
        painter.fillRect(squareRect(*selected_), selColor);
    }

    // Подсветка возможных ходов выбранной фигуры
    for (const Move& m : selectedLegalMoves_) {
        QRect rc = squareRect(m.to);
        bool isCapture = !board_.at(m.to).isEmpty() || m.flag == MoveFlag::EnPassant;
        painter.save();
        painter.setRenderHint(QPainter::Antialiasing, true);
        if (isCapture) {
            QPen pen(QColor(200, 60, 60, 200));
            pen.setWidth(std::max(2, squareSize_ / 18));
            painter.setPen(pen);
            painter.setBrush(Qt::NoBrush);
            int margin = squareSize_ / 10;
            painter.drawEllipse(rc.adjusted(margin, margin, -margin, -margin));
        } else {
            painter.setPen(Qt::NoPen);
            painter.setBrush(QColor(40, 40, 40, 90));
            int r = squareSize_ / 6;
            QPoint c = rc.center();
            painter.drawEllipse(c, r, r);
        }
        painter.restore();
    }

    // Подсветка короля под шахом
    Color side = board_.sideToMove();
    if (board_.isKingInCheck(side)) {
        Square ks = board_.kingSquare(side);
        if (ks.isValid()) {
            QColor checkColor(220, 60, 60, 160);
            QRect rc = squareRect(ks);
            painter.save();
            QRadialGradient grad(rc.center(), rc.width() * 0.7);
            grad.setColorAt(0.0, checkColor);
            grad.setColorAt(1.0, QColor(220, 60, 60, 0));
            painter.setBrush(grad);
            painter.setPen(Qt::NoPen);
            painter.drawRect(rc);
            painter.restore();
        }
    }
}

void ChessBoardWidget::drawPieces(QPainter& painter) {
    for (int f = 0; f < 8; ++f) {
        for (int r = 0; r < 8; ++r) {
            Square sq(f, r);
            Piece p = board_.at(sq);
            if (p.isEmpty()) continue;

            QRect rc = squareRect(sq);
            QString key = pieceImageKey(p);

            auto it = pieceImages_.find(key);
            if (it != pieceImages_.end() && !it->isNull()) {
                int margin = squareSize_ / 16;
                QRect target = rc.adjusted(margin, margin, -margin, -margin);
                QPixmap scaled = it->scaled(target.size(), Qt::KeepAspectRatio, Qt::SmoothTransformation);
                QPoint topLeft(target.left() + (target.width() - scaled.width()) / 2,
                                target.top() + (target.height() - scaled.height()) / 2);
                painter.drawPixmap(topLeft, scaled);
            } else {
                // Запасной вариант: рисуем юникодный символ фигуры
                QString sym = unicodeForPiece(p);
                QFont font = painter.font();
                font.setPointSize(static_cast<int>(squareSize_ * 0.6));
                painter.setFont(font);

                // Лёгкая обводка для контраста с фоном клетки
                painter.setPen(QColor(0, 0, 0, 60));
                QRect shadowRect = rc.translated(1, 1);
                painter.drawText(shadowRect, Qt::AlignCenter, sym);

                painter.setPen(p.color == Color::White ? QColor(250, 250, 250) : QColor(20, 20, 20));
                painter.drawText(rc, Qt::AlignCenter, sym);
            }
        }
    }
}

// ----------------------------------------------------------------------
// Обработка кликов
// ----------------------------------------------------------------------

void ChessBoardWidget::mousePressEvent(QMouseEvent* event) {
    if (event->button() != Qt::LeftButton) return;
    Square sq = widgetPosToSquare(event->pos());
    if (!sq.isValid()) return;
    handleSquareClicked(sq);
}

void ChessBoardWidget::handleSquareClicked(Square sq) {
    GameStatus st = board_.status();
    if (st == GameStatus::Checkmate || st == GameStatus::Stalemate ||
        st == GameStatus::DrawByFiftyMoves || st == GameStatus::DrawByInsufficientMaterial) {
        return; // игра окончена, ходы больше не принимаются
    }

    if (!selected_) {
        // Ничего не выбрано — пытаемся выбрать фигуру текущей стороны
        Piece p = board_.at(sq);
        if (p.isEmpty() || p.color != board_.sideToMove()) {
            return;
        }
        selected_ = sq;
        selectedLegalMoves_ = board_.legalMovesFrom(sq);
        update();
        return;
    }

    if (*selected_ == sq) {
        // Повторный клик по той же фигуре — снимаем выделение
        clearSelection();
        update();
        return;
    }

    // Если кликнули на другую свою фигуру — переключаем выбор на неё
    Piece clickedPiece = board_.at(sq);
    if (!clickedPiece.isEmpty() && clickedPiece.color == board_.sideToMove()) {
        selected_ = sq;
        selectedLegalMoves_ = board_.legalMovesFrom(sq);
        update();
        return;
    }

    // Пытаемся сделать ход с выбранной клетки на текущую
    Square from = *selected_;
    tryMakeMove(from, sq);
}

PieceType ChessBoardWidget::askPromotionChoice(Color sideToMove) {
    QStringList options;
    options << tr("Королева") << tr("Ладья") << tr("Слон") << tr("Конь");
    QString title = (sideToMove == Color::White) ? tr("Превращение пешки (белые)")
                                                   : tr("Превращение пешки (чёрные)");
    bool ok = false;
    QString choice = QInputDialog::getItem(this, title, tr("Выберите фигуру для превращения:"),
                                            options, 0, false, &ok);
    if (!ok) return PieceType::Queen; // по умолчанию, если диалог закрыли иначе
    if (choice == options[1]) return PieceType::Rook;
    if (choice == options[2]) return PieceType::Bishop;
    if (choice == options[3]) return PieceType::Knight;
    return PieceType::Queen;
}

void ChessBoardWidget::tryMakeMove(Square from, Square to) {
    Piece moving = board_.at(from);

    // Определяем, является ли это потенциальным превращением пешки —
    // спрашиваем выбор фигуры только в этом случае.
    PieceType promo = PieceType::None;
    bool isPromotionCandidate = (moving.type == PieceType::Pawn) &&
                                 ((moving.color == Color::White && to.rank == 7) ||
                                  (moving.color == Color::Black && to.rank == 0));
    if (isPromotionCandidate && board_.isMoveLegal(from, to, PieceType::Queen)) {
        promo = askPromotionChoice(moving.color);
    }

    bool ok = board_.makeMove(from, to, promo == PieceType::None ? PieceType::Queen : promo);
    if (!ok) {
        // Нелегальный ход — просто снимаем выделение без сообщения об ошибке,
        // это привычное поведение для шахматных интерфейсов
        clearSelection();
        update();
        return;
    }

    lastMove_ = board_.history().back().move;
    clearSelection();
    update();

    emit moveMade(lastMove_.value());
    emitStatusForCurrentPosition();
}

void ChessBoardWidget::clearSelection() {
    selected_.reset();
    selectedLegalMoves_.clear();
}

void ChessBoardWidget::emitStatusForCurrentPosition() {
    GameStatus st = board_.status();
    Color side = board_.sideToMove();
    QString sideName = (side == Color::White) ? tr("белых") : tr("чёрных");

    switch (st) {
        case GameStatus::Checkmate: {
            QString winner = (side == Color::White) ? tr("Чёрные") : tr("Белые");
            QString msg = tr("Мат! Победили %1.").arg(winner);
            emit statusMessage(msg);
            emit gameOver(st);
            break;
        }
        case GameStatus::Stalemate:
            emit statusMessage(tr("Пат. Ничья."));
            emit gameOver(st);
            break;
        case GameStatus::DrawByFiftyMoves:
            emit statusMessage(tr("Ничья по правилу 50 ходов."));
            emit gameOver(st);
            break;
        case GameStatus::DrawByInsufficientMaterial:
            emit statusMessage(tr("Ничья: недостаточно материала для мата."));
            emit gameOver(st);
            break;
        case GameStatus::Check:
            emit statusMessage(tr("Шах! Ход %1.").arg(sideName));
            break;
        case GameStatus::InProgress:
        default:
            emit statusMessage(tr("Ход %1.").arg(sideName));
            break;
    }
}

// ----------------------------------------------------------------------
// Публичные методы управления игрой
// ----------------------------------------------------------------------

void ChessBoardWidget::newGame() {
    board_.reset();
    clearSelection();
    lastMove_.reset();
    update();
    emit statusMessage(tr("Новая игра. Ход белых."));
}

bool ChessBoardWidget::undo() {
    bool ok = board_.undoMove();
    if (ok) {
        clearSelection();
        if (!board_.history().empty()) {
            lastMove_ = board_.history().back().move;
        } else {
            lastMove_.reset();
        }
        update();
        emitStatusForCurrentPosition();
    }
    return ok;
}

void ChessBoardWidget::setFlipped(bool flipped) {
    flipped_ = flipped;
    update();
}
