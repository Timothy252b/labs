#include "MainWindow.h"
#include "ChessBoardWidget.h"

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QListWidget>
#include <QLabel>
#include <QPushButton>
#include <QFont>
#include <QMessageBox>

using namespace chess;

MainWindow::MainWindow(QWidget* parent) : QMainWindow(parent) {
    setWindowTitle(tr("Шахматы"));
    setupUi();
    resize(900, 680);
}

void MainWindow::setupUi() {
    QWidget* central = new QWidget(this);
    setCentralWidget(central);

    QHBoxLayout* mainLayout = new QHBoxLayout(central);

    // ---- Доска (слева) ----
    boardWidget_ = new ChessBoardWidget(central);
    mainLayout->addWidget(boardWidget_, /*stretch=*/3);

    // ---- Боковая панель (справа) ----
    QWidget* sidePanel = new QWidget(central);
    QVBoxLayout* sideLayout = new QVBoxLayout(sidePanel);

    statusLabel_ = new QLabel(tr("Новая игра. Ход белых."), sidePanel);
    QFont statusFont = statusLabel_->font();
    statusFont.setPointSize(statusFont.pointSize() + 2);
    statusFont.setBold(true);
    statusLabel_->setFont(statusFont);
    statusLabel_->setWordWrap(true);
    sideLayout->addWidget(statusLabel_);

    QLabel* historyLabel = new QLabel(tr("История ходов:"), sidePanel);
    sideLayout->addWidget(historyLabel);

    moveListWidget_ = new QListWidget(sidePanel);
    sideLayout->addWidget(moveListWidget_, /*stretch=*/1);

    newGameButton_ = new QPushButton(tr("Новая игра"), sidePanel);
    undoButton_ = new QPushButton(tr("Отменить ход"), sidePanel);
    flipButton_ = new QPushButton(tr("Перевернуть доску"), sidePanel);

    sideLayout->addWidget(newGameButton_);
    sideLayout->addWidget(undoButton_);
    sideLayout->addWidget(flipButton_);

    mainLayout->addWidget(sidePanel, /*stretch=*/1);

    // ---- Соединения сигналов ----
    connect(boardWidget_, &ChessBoardWidget::moveMade, this, &MainWindow::onMoveMade);
    connect(boardWidget_, &ChessBoardWidget::gameOver, this, &MainWindow::onGameOver);
    connect(boardWidget_, &ChessBoardWidget::statusMessage, this, &MainWindow::onStatusMessage);
    connect(newGameButton_, &QPushButton::clicked, this, &MainWindow::onNewGameClicked);
    connect(undoButton_, &QPushButton::clicked, this, &MainWindow::onUndoClicked);
    connect(flipButton_, &QPushButton::clicked, this, &MainWindow::onFlipClicked);
}

QString MainWindow::moveToAlgebraic(const Move& move) const {
    // Простая (не строго стандартная SAN) запись хода: "e2-e4", "Nf3-d4" и т.п.
    // Для полноценной SAN-нотации нужно учитывать неоднозначность ходов между
    // одинаковыми фигурами, что выходит за рамки базовой версии.
    QString flagSuffix;
    switch (move.flag) {
        case MoveFlag::CastleKingside:  return QStringLiteral("O-O");
        case MoveFlag::CastleQueenside: return QStringLiteral("O-O-O");
        case MoveFlag::EnPassant:       flagSuffix = " (взятие на проходе)"; break;
        case MoveFlag::Promotion: {
            QString promoLetter;
            switch (move.promotion) {
                case PieceType::Queen:  promoLetter = "Q"; break;
                case PieceType::Rook:   promoLetter = "R"; break;
                case PieceType::Bishop: promoLetter = "B"; break;
                case PieceType::Knight: promoLetter = "N"; break;
                default: break;
            }
            flagSuffix = "=" + promoLetter;
            break;
        }
        default: break;
    }
    return QString::fromStdString(move.from.toString()) + "-" +
           QString::fromStdString(move.to.toString()) + flagSuffix;
}

void MainWindow::onMoveMade(const Move& move) {
    moveCounterForDisplay_++;
    QString text = QString::number((moveCounterForDisplay_ + 1) / 2) + ". " + moveToAlgebraic(move);
    moveListWidget_->addItem(text);
    moveListWidget_->scrollToBottom();
}

void MainWindow::onGameOver(GameStatus status) {
    QString title = tr("Игра окончена");
    QString text;
    switch (status) {
        case GameStatus::Checkmate:
            text = statusLabel_->text();
            break;
        case GameStatus::Stalemate:
            text = tr("Пат — партия закончилась вничью.");
            break;
        case GameStatus::DrawByFiftyMoves:
            text = tr("Ничья по правилу 50 ходов.");
            break;
        case GameStatus::DrawByInsufficientMaterial:
            text = tr("Ничья: на доске недостаточно материала для мата.");
            break;
        default:
            text = tr("Партия завершена.");
            break;
    }
    QMessageBox::information(this, title, text);
}

void MainWindow::onStatusMessage(const QString& text) {
    statusLabel_->setText(text);
}

void MainWindow::onNewGameClicked() {
    boardWidget_->newGame();
    moveListWidget_->clear();
    moveCounterForDisplay_ = 0;
}

void MainWindow::onUndoClicked() {
    if (boardWidget_->undo()) {
        if (moveListWidget_->count() > 0) {
            delete moveListWidget_->takeItem(moveListWidget_->count() - 1);
            if (moveCounterForDisplay_ > 0) moveCounterForDisplay_--;
        }
    }
}

void MainWindow::onFlipClicked() {
    boardWidget_->setFlipped(!boardWidget_->isFlipped());
}
