#include "Board.h"
#include <sstream>
#include <algorithm>
#include <cctype>

namespace chess {

Board::Board() {
    reset();
}

void Board::reset() {
    squares_.fill(Piece());

    auto put = [this](int file, int rank, PieceType t, Color c) {
        setPiece(Square(file, rank), Piece(t, c));
    };

    // Белые — ряд 0 (1-я горизонталь) и ряд 1 (2-я горизонталь)
    const PieceType backRank[8] = {
        PieceType::Rook, PieceType::Knight, PieceType::Bishop, PieceType::Queen,
        PieceType::King, PieceType::Bishop, PieceType::Knight, PieceType::Rook
    };
    for (int f = 0; f < 8; ++f) {
        put(f, 0, backRank[f], Color::White);
        put(f, 1, PieceType::Pawn, Color::White);
        put(f, 6, PieceType::Pawn, Color::Black);
        put(f, 7, backRank[f], Color::Black);
    }

    sideToMove_ = Color::White;
    whiteKingMoved_ = blackKingMoved_ = false;
    whiteRookKingsideMoved_ = whiteRookQueensideMoved_ = false;
    blackRookKingsideMoved_ = blackRookQueensideMoved_ = false;
    enPassantTarget_ = Square();
    halfmoveClock_ = 0;
    fullmoveNumber_ = 1;
    history_.clear();
}

Piece Board::at(Square sq) const {
    if (!sq.isValid()) return Piece();
    return squares_[sq.index()];
}

Square Board::kingSquare(Color c) const {
    for (int i = 0; i < 64; ++i) {
        if (squares_[i].type == PieceType::King && squares_[i].color == c) {
            return Square::fromIndex(i);
        }
    }
    return Square(); // не должно происходить в нормальной партии
}

// ----------------------------------------------------------------------
// Проверка атакована ли клетка
// ----------------------------------------------------------------------

bool Board::isSquareAttacked(Square sq, Color attacker) const {
    // Пешки
    {
        int dir = (attacker == Color::White) ? -1 : 1; // атакующая пешка стоит "ниже/выше" клетки
        int pawnRank = sq.rank + dir;
        for (int df : {-1, 1}) {
            Square p(sq.file + df, pawnRank);
            if (p.isValid()) {
                Piece pc = at(p);
                if (pc.type == PieceType::Pawn && pc.color == attacker) return true;
            }
        }
    }
    // Конь
    {
        static const int dx[8] = {1,1,-1,-1,2,2,-2,-2};
        static const int dy[8] = {2,-2,2,-2,1,-1,1,-1};
        for (int i = 0; i < 8; ++i) {
            Square p(sq.file + dx[i], sq.rank + dy[i]);
            if (p.isValid()) {
                Piece pc = at(p);
                if (pc.type == PieceType::Knight && pc.color == attacker) return true;
            }
        }
    }
    // Король (для проверки соседства королей / атаки на клетку рядом с чужим королём)
    {
        for (int df = -1; df <= 1; ++df) {
            for (int dr = -1; dr <= 1; ++dr) {
                if (df == 0 && dr == 0) continue;
                Square p(sq.file + df, sq.rank + dr);
                if (p.isValid()) {
                    Piece pc = at(p);
                    if (pc.type == PieceType::King && pc.color == attacker) return true;
                }
            }
        }
    }
    // Скользящие фигуры: ладья/королева по горизонтали-вертикали
    {
        static const std::pair<int,int> rookDirs[4] = {{1,0},{-1,0},{0,1},{0,-1}};
        for (auto [dfx, dfy] : rookDirs) {
            int f = sq.file + dfx, r = sq.rank + dfy;
            while (Square(f, r).isValid()) {
                Piece pc = at(Square(f, r));
                if (!pc.isEmpty()) {
                    if (pc.color == attacker && (pc.type == PieceType::Rook || pc.type == PieceType::Queen)) {
                        return true;
                    }
                    break; // фигура (своя или чужая) блокирует луч
                }
                f += dfx; r += dfy;
            }
        }
    }
    // Скользящие фигуры: слон/королева по диагоналям
    {
        static const std::pair<int,int> bishopDirs[4] = {{1,1},{1,-1},{-1,1},{-1,-1}};
        for (auto [dfx, dfy] : bishopDirs) {
            int f = sq.file + dfx, r = sq.rank + dfy;
            while (Square(f, r).isValid()) {
                Piece pc = at(Square(f, r));
                if (!pc.isEmpty()) {
                    if (pc.color == attacker && (pc.type == PieceType::Bishop || pc.type == PieceType::Queen)) {
                        return true;
                    }
                    break;
                }
                f += dfx; r += dfy;
            }
        }
    }
    return false;
}

bool Board::isKingInCheck(Color c) const {
    Square ks = kingSquare(c);
    if (!ks.isValid()) return false;
    return isSquareAttacked(ks, opposite(c));
}

// ----------------------------------------------------------------------
// Генерация псевдо-легальных ходов
// ----------------------------------------------------------------------

void Board::generateSlidingMoves(Square from, const std::vector<std::pair<int,int>>& directions,
                                  std::vector<Move>& out) const {
    Piece p = at(from);
    for (auto [dfx, dfy] : directions) {
        int f = from.file + dfx, r = from.rank + dfy;
        while (Square(f, r).isValid()) {
            Square to(f, r);
            Piece target = at(to);
            if (target.isEmpty()) {
                out.emplace_back(from, to);
            } else {
                if (target.color != p.color) {
                    out.emplace_back(from, to);
                }
                break; // дальше луч не идёт
            }
            f += dfx; r += dfy;
        }
    }
}

void Board::generateBishopMoves(Square from, std::vector<Move>& out) const {
    generateSlidingMoves(from, {{1,1},{1,-1},{-1,1},{-1,-1}}, out);
}

void Board::generateRookMoves(Square from, std::vector<Move>& out) const {
    generateSlidingMoves(from, {{1,0},{-1,0},{0,1},{0,-1}}, out);
}

void Board::generateQueenMoves(Square from, std::vector<Move>& out) const {
    generateSlidingMoves(from, {{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}}, out);
}

void Board::generateKnightMoves(Square from, std::vector<Move>& out) const {
    Piece p = at(from);
    static const int dx[8] = {1,1,-1,-1,2,2,-2,-2};
    static const int dy[8] = {2,-2,2,-2,1,-1,1,-1};
    for (int i = 0; i < 8; ++i) {
        Square to(from.file + dx[i], from.rank + dy[i]);
        if (!to.isValid()) continue;
        Piece target = at(to);
        if (target.isEmpty() || target.color != p.color) {
            out.emplace_back(from, to);
        }
    }
}

void Board::generateKingMoves(Square from, std::vector<Move>& out) const {
    Piece p = at(from);
    for (int df = -1; df <= 1; ++df) {
        for (int dr = -1; dr <= 1; ++dr) {
            if (df == 0 && dr == 0) continue;
            Square to(from.file + df, from.rank + dr);
            if (!to.isValid()) continue;
            Piece target = at(to);
            if (target.isEmpty() || target.color != p.color) {
                out.emplace_back(from, to);
            }
        }
    }

    // Рокировка
    Color c = p.color;
    bool kingMoved = (c == Color::White) ? whiteKingMoved_ : blackKingMoved_;
    if (kingMoved) return;
    if (isKingInCheck(c)) return; // нельзя рокироваться под шахом

    int rank = (c == Color::White) ? 0 : 7;
    if (from != Square(4, rank)) return; // король не на исходной клетке — рокировка невозможна

    Color enemy = opposite(c);

    // Короткая рокировка (kingside): король e->g, ладья h->f
    bool rookKingsideMoved = (c == Color::White) ? whiteRookKingsideMoved_ : blackRookKingsideMoved_;
    if (!rookKingsideMoved) {
        Piece rook = at(Square(7, rank));
        Piece f1 = at(Square(5, rank));
        Piece g1 = at(Square(6, rank));
        if (rook.type == PieceType::Rook && rook.color == c &&
            f1.isEmpty() && g1.isEmpty() &&
            !isSquareAttacked(Square(4, rank), enemy) &&
            !isSquareAttacked(Square(5, rank), enemy) &&
            !isSquareAttacked(Square(6, rank), enemy)) {
            out.emplace_back(from, Square(6, rank), MoveFlag::CastleKingside);
        }
    }

    // Длинная рокировка (queenside): король e->c, ладья a->d
    bool rookQueensideMoved = (c == Color::White) ? whiteRookQueensideMoved_ : blackRookQueensideMoved_;
    if (!rookQueensideMoved) {
        Piece rook = at(Square(0, rank));
        Piece b1 = at(Square(1, rank));
        Piece c1 = at(Square(2, rank));
        Piece d1 = at(Square(3, rank));
        if (rook.type == PieceType::Rook && rook.color == c &&
            b1.isEmpty() && c1.isEmpty() && d1.isEmpty() &&
            !isSquareAttacked(Square(4, rank), enemy) &&
            !isSquareAttacked(Square(3, rank), enemy) &&
            !isSquareAttacked(Square(2, rank), enemy)) {
            out.emplace_back(from, Square(2, rank), MoveFlag::CastleQueenside);
        }
    }
}

void Board::generatePawnMoves(Square from, std::vector<Move>& out) const {
    Piece p = at(from);
    Color c = p.color;
    int dir = (c == Color::White) ? 1 : -1;
    int startRank = (c == Color::White) ? 1 : 6;
    int promoRank = (c == Color::White) ? 7 : 0;

    auto addWithPromotion = [&](Square from_, Square to_, MoveFlag flag) {
        if (to_.rank == promoRank) {
            out.emplace_back(from_, to_, MoveFlag::Promotion, PieceType::Queen);
            out.emplace_back(from_, to_, MoveFlag::Promotion, PieceType::Rook);
            out.emplace_back(from_, to_, MoveFlag::Promotion, PieceType::Bishop);
            out.emplace_back(from_, to_, MoveFlag::Promotion, PieceType::Knight);
        } else {
            out.emplace_back(from_, to_, flag);
        }
    };

    // Ход вперёд на одну клетку
    Square oneStep(from.file, from.rank + dir);
    if (oneStep.isValid() && at(oneStep).isEmpty()) {
        addWithPromotion(from, oneStep, MoveFlag::Normal);

        // Ход на две клетки с начальной позиции
        if (from.rank == startRank) {
            Square twoStep(from.file, from.rank + 2 * dir);
            if (twoStep.isValid() && at(twoStep).isEmpty()) {
                out.emplace_back(from, twoStep, MoveFlag::DoublePawn);
            }
        }
    }

    // Взятия по диагонали
    for (int df : {-1, 1}) {
        Square to(from.file + df, from.rank + dir);
        if (!to.isValid()) continue;
        Piece target = at(to);
        if (!target.isEmpty() && target.color != c) {
            addWithPromotion(from, to, MoveFlag::Normal);
        } else if (to == enPassantTarget_ && enPassantTarget_.isValid()) {
            out.emplace_back(from, to, MoveFlag::EnPassant);
        }
    }
}

void Board::generatePseudoLegalMovesForSquare(Square from, std::vector<Move>& out) const {
    Piece p = at(from);
    if (p.isEmpty()) return;
    switch (p.type) {
        case PieceType::Pawn:   generatePawnMoves(from, out);   break;
        case PieceType::Knight: generateKnightMoves(from, out); break;
        case PieceType::Bishop: generateBishopMoves(from, out); break;
        case PieceType::Rook:   generateRookMoves(from, out);   break;
        case PieceType::Queen:  generateQueenMoves(from, out);  break;
        case PieceType::King:   generateKingMoves(from, out);   break;
        default: break;
    }
}

std::vector<Move> Board::generatePseudoLegalMoves(Color side) const {
    std::vector<Move> moves;
    moves.reserve(64);
    for (int i = 0; i < 64; ++i) {
        if (squares_[i].isEmpty() || squares_[i].color != side) continue;
        generatePseudoLegalMovesForSquare(Square::fromIndex(i), moves);
    }
    return moves;
}

// ----------------------------------------------------------------------
// Применение / откат хода (внутренний, без проверки легальности)
// ----------------------------------------------------------------------

MoveRecord Board::applyMoveInternal(const Move& m) {
    MoveRecord rec;
    rec.move = m;
    rec.movedPiece = at(m.from);
    rec.capturedSquare = m.to;
    rec.capturedPiece = at(m.to);

    rec.prevWhiteKingMoved = whiteKingMoved_;
    rec.prevBlackKingMoved = blackKingMoved_;
    rec.prevWhiteRookKingsideMoved = whiteRookKingsideMoved_;
    rec.prevWhiteRookQueensideMoved = whiteRookQueensideMoved_;
    rec.prevBlackRookKingsideMoved = blackRookKingsideMoved_;
    rec.prevBlackRookQueensideMoved = blackRookQueensideMoved_;
    rec.prevEnPassantTarget = enPassantTarget_;
    rec.prevHalfmoveClock = halfmoveClock_;

    Piece moving = at(m.from);
    Color c = moving.color;

    // Взятие на проходе: реальная взятая фигура стоит не на m.to, а сбоку от неё
    if (m.flag == MoveFlag::EnPassant) {
        int capturedRank = (c == Color::White) ? m.to.rank - 1 : m.to.rank + 1;
        Square capSq(m.to.file, capturedRank);
        rec.capturedSquare = capSq;
        rec.capturedPiece = at(capSq);
        clearSquare(capSq);
    }

    // Перемещаем фигуру
    clearSquare(m.from);
    if (m.flag == MoveFlag::Promotion) {
        setPiece(m.to, Piece(m.promotion, c));
    } else {
        setPiece(m.to, moving);
    }

    // Рокировка — дополнительно двигаем ладью
    if (m.flag == MoveFlag::CastleKingside) {
        int rank = m.from.rank;
        Piece rook = at(Square(7, rank));
        clearSquare(Square(7, rank));
        setPiece(Square(5, rank), rook);
    } else if (m.flag == MoveFlag::CastleQueenside) {
        int rank = m.from.rank;
        Piece rook = at(Square(0, rank));
        clearSquare(Square(0, rank));
        setPiece(Square(3, rank), rook);
    }

    // Обновление прав на рокировку
    if (moving.type == PieceType::King) {
        if (c == Color::White) whiteKingMoved_ = true; else blackKingMoved_ = true;
    }
    if (moving.type == PieceType::Rook) {
        if (c == Color::White) {
            if (m.from == Square(0, 0)) whiteRookQueensideMoved_ = true;
            if (m.from == Square(7, 0)) whiteRookKingsideMoved_ = true;
        } else {
            if (m.from == Square(0, 7)) blackRookQueensideMoved_ = true;
            if (m.from == Square(7, 7)) blackRookKingsideMoved_ = true;
        }
    }
    // Если ладья была взята на исходной клетке — теряем право на рокировку с этой стороны
    if (rec.capturedPiece.type == PieceType::Rook) {
        if (rec.capturedSquare == Square(0, 0)) whiteRookQueensideMoved_ = true;
        if (rec.capturedSquare == Square(7, 0)) whiteRookKingsideMoved_ = true;
        if (rec.capturedSquare == Square(0, 7)) blackRookQueensideMoved_ = true;
        if (rec.capturedSquare == Square(7, 7)) blackRookKingsideMoved_ = true;
    }

    // Поле для взятия на проходе на следующий ход
    if (m.flag == MoveFlag::DoublePawn) {
        int midRank = (m.from.rank + m.to.rank) / 2;
        enPassantTarget_ = Square(m.from.file, midRank);
    } else {
        enPassantTarget_ = Square();
    }

    // Счётчик полуходов для правила 50 ходов
    if (moving.type == PieceType::Pawn || !rec.capturedPiece.isEmpty()) {
        halfmoveClock_ = 0;
    } else {
        halfmoveClock_++;
    }

    if (c == Color::Black) fullmoveNumber_++;
    sideToMove_ = opposite(c);

    return rec;
}

void Board::revertMoveInternal(const MoveRecord& rec) {
    const Move& m = rec.move;
    Color c = rec.movedPiece.color;

    // Возвращаем перемещённую фигуру на исходную клетку
    clearSquare(m.to);
    setPiece(m.from, rec.movedPiece);

    // Восстанавливаем взятую фигуру (если была)
    if (!rec.capturedPiece.isEmpty()) {
        setPiece(rec.capturedSquare, rec.capturedPiece);
    } else if (m.flag == MoveFlag::EnPassant) {
        clearSquare(rec.capturedSquare); // на всякий случай, если capturedPiece пуст
    }

    // Откат рокировки — возвращаем ладью
    if (m.flag == MoveFlag::CastleKingside) {
        int rank = m.from.rank;
        Piece rook = at(Square(5, rank));
        clearSquare(Square(5, rank));
        setPiece(Square(7, rank), rook);
    } else if (m.flag == MoveFlag::CastleQueenside) {
        int rank = m.from.rank;
        Piece rook = at(Square(3, rank));
        clearSquare(Square(3, rank));
        setPiece(Square(0, rank), rook);
    }

    whiteKingMoved_ = rec.prevWhiteKingMoved;
    blackKingMoved_ = rec.prevBlackKingMoved;
    whiteRookKingsideMoved_ = rec.prevWhiteRookKingsideMoved;
    whiteRookQueensideMoved_ = rec.prevWhiteRookQueensideMoved;
    blackRookKingsideMoved_ = rec.prevBlackRookKingsideMoved;
    blackRookQueensideMoved_ = rec.prevBlackRookQueensideMoved;
    enPassantTarget_ = rec.prevEnPassantTarget;
    halfmoveClock_ = rec.prevHalfmoveClock;

    if (c == Color::Black) fullmoveNumber_--;
    sideToMove_ = c;
}

// ----------------------------------------------------------------------
// Легальные ходы (с фильтрацией ходов, оставляющих короля под шахом)
// ----------------------------------------------------------------------

std::vector<Move> Board::generateLegalMoves() const {
    std::vector<Move> pseudo = generatePseudoLegalMoves(sideToMove_);
    std::vector<Move> legal;
    legal.reserve(pseudo.size());

    Board copy = *this;
    for (const Move& m : pseudo) {
        MoveRecord rec = copy.applyMoveInternal(m);
        bool kingSafe = !copy.isKingInCheck(rec.movedPiece.color);
        copy.revertMoveInternal(rec);
        if (kingSafe) legal.push_back(m);
    }
    return legal;
}

std::vector<Move> Board::legalMovesFrom(Square from) const {
    std::vector<Move> result;
    for (const Move& m : generateLegalMoves()) {
        if (m.from == from) result.push_back(m);
    }
    return result;
}

std::optional<Move> Board::findLegalMove(Square from, Square to, PieceType promotion) const {
    std::vector<Move> legal = generateLegalMoves();
    for (const Move& lm : legal) {
        if (lm.from == from && lm.to == to) {
            if (lm.flag == MoveFlag::Promotion) {
                PieceType wanted = (promotion == PieceType::None) ? PieceType::Queen : promotion;
                if (lm.promotion == wanted) return lm;
            } else {
                return lm;
            }
        }
    }
    return std::nullopt;
}

bool Board::isMoveLegal(Square from, Square to, PieceType promotion) const {
    return findLegalMove(from, to, promotion).has_value();
}

bool Board::isMoveLegal(const Move& m) const {
    PieceType promo = (m.flag == MoveFlag::Promotion) ? m.promotion : PieceType::None;
    return isMoveLegal(m.from, m.to, promo);
}

bool Board::makeMove(Square from, Square to, PieceType promotion) {
    Piece p = at(from);
    if (p.isEmpty() || p.color != sideToMove_) return false;

    std::optional<Move> found = findLegalMove(from, to, promotion);
    if (!found) return false;

    MoveRecord rec = applyMoveInternal(*found);
    history_.push_back(rec);
    return true;
}

bool Board::makeMove(const Move& m) {
    PieceType promo = (m.flag == MoveFlag::Promotion) ? m.promotion : PieceType::None;
    return makeMove(m.from, m.to, promo == PieceType::None ? PieceType::Queen : promo);
}

bool Board::undoMove() {
    if (history_.empty()) return false;
    MoveRecord rec = history_.back();
    history_.pop_back();
    revertMoveInternal(rec);
    return true;
}

bool Board::sideToMoveHasNoMoves() const {
    return generateLegalMoves().empty();
}

bool Board::isCheckmate() const {
    return isKingInCheck(sideToMove_) && sideToMoveHasNoMoves();
}

bool Board::isStalemate() const {
    return !isKingInCheck(sideToMove_) && sideToMoveHasNoMoves();
}

GameStatus Board::status() const {
    if (isCheckmate()) return GameStatus::Checkmate;
    if (isStalemate()) return GameStatus::Stalemate;
    if (halfmoveClock_ >= 100) return GameStatus::DrawByFiftyMoves; // 50 ходов = 100 полуходов

    // Недостаточность материала для мата (упрощённая проверка):
    // король против короля, король+конь против короля, король+слон против короля
    {
        int whiteMinor = 0, blackMinor = 0, otherPieces = 0;
        for (const Piece& pc : squares_) {
            if (pc.isEmpty() || pc.type == PieceType::King) continue;
            if (pc.type == PieceType::Knight || pc.type == PieceType::Bishop) {
                if (pc.color == Color::White) whiteMinor++; else blackMinor++;
            } else {
                otherPieces++;
            }
        }
        if (otherPieces == 0 && whiteMinor <= 1 && blackMinor <= 1 && (whiteMinor + blackMinor) <= 1) {
            return GameStatus::DrawByInsufficientMaterial;
        }
    }

    if (isKingInCheck(sideToMove_)) return GameStatus::Check;
    return GameStatus::InProgress;
}

// ----------------------------------------------------------------------
// Отображение
// ----------------------------------------------------------------------

std::string Board::toAscii() const {
    static const char whiteSym[7] = {' ', 'P','N','B','R','Q','K'};
    static const char blackSym[7] = {' ', 'p','n','b','r','q','k'};
    std::ostringstream oss;
    for (int rank = 7; rank >= 0; --rank) {
        oss << (rank + 1) << "  ";
        for (int file = 0; file < 8; ++file) {
            Piece p = at(Square(file, rank));
            char c = '.';
            if (!p.isEmpty()) {
                c = (p.color == Color::White) ? whiteSym[(int)p.type] : blackSym[(int)p.type];
            }
            oss << c << ' ';
        }
        oss << '\n';
    }
    oss << "   a b c d e f g h\n";
    return oss.str();
}

std::string Board::toFEN() const {
    static const char whiteSym[7] = {' ', 'P','N','B','R','Q','K'};
    static const char blackSym[7] = {' ', 'p','n','b','r','q','k'};
    std::ostringstream oss;
    for (int rank = 7; rank >= 0; --rank) {
        int empty = 0;
        for (int file = 0; file < 8; ++file) {
            Piece p = at(Square(file, rank));
            if (p.isEmpty()) {
                empty++;
            } else {
                if (empty > 0) { oss << empty; empty = 0; }
                oss << ((p.color == Color::White) ? whiteSym[(int)p.type] : blackSym[(int)p.type]);
            }
        }
        if (empty > 0) oss << empty;
        if (rank > 0) oss << '/';
    }
    oss << ' ' << (sideToMove_ == Color::White ? 'w' : 'b') << ' ';

    std::string castling;
    if (!whiteKingMoved_ && !whiteRookKingsideMoved_) castling += 'K';
    if (!whiteKingMoved_ && !whiteRookQueensideMoved_) castling += 'Q';
    if (!blackKingMoved_ && !blackRookKingsideMoved_) castling += 'k';
    if (!blackKingMoved_ && !blackRookQueensideMoved_) castling += 'q';
    oss << (castling.empty() ? "-" : castling) << ' ';

    oss << (enPassantTarget_.isValid() ? enPassantTarget_.toString() : "-") << ' ';
    oss << halfmoveClock_ << ' ' << fullmoveNumber_;
    return oss.str();
}

bool Board::loadFEN(const std::string& fen) {
    std::istringstream iss(fen);
    std::string boardPart, sidePart, castlingPart, epPart, halfmovePart, fullmovePart;
    if (!(iss >> boardPart >> sidePart >> castlingPart >> epPart)) return false;
    if (!(iss >> halfmovePart)) halfmovePart = "0";
    if (!(iss >> fullmovePart)) fullmovePart = "1";

    squares_.fill(Piece());

    int file = 0, rank = 7;
    for (char ch : boardPart) {
        if (ch == '/') {
            rank--;
            file = 0;
            continue;
        }
        if (std::isdigit(static_cast<unsigned char>(ch))) {
            file += (ch - '0');
            continue;
        }
        PieceType t = PieceType::None;
        Color c = std::isupper(static_cast<unsigned char>(ch)) ? Color::White : Color::Black;
        switch (std::tolower(static_cast<unsigned char>(ch))) {
            case 'p': t = PieceType::Pawn; break;
            case 'n': t = PieceType::Knight; break;
            case 'b': t = PieceType::Bishop; break;
            case 'r': t = PieceType::Rook; break;
            case 'q': t = PieceType::Queen; break;
            case 'k': t = PieceType::King; break;
            default: return false;
        }
        if (file < 0 || file > 7 || rank < 0 || rank > 7) return false;
        setPiece(Square(file, rank), Piece(t, c));
        file++;
    }

    sideToMove_ = (sidePart == "b") ? Color::Black : Color::White;

    whiteKingMoved_ = castlingPart.find('K') == std::string::npos && castlingPart.find('Q') == std::string::npos;
    blackKingMoved_ = castlingPart.find('k') == std::string::npos && castlingPart.find('q') == std::string::npos;
    whiteRookKingsideMoved_ = castlingPart.find('K') == std::string::npos;
    whiteRookQueensideMoved_ = castlingPart.find('Q') == std::string::npos;
    blackRookKingsideMoved_ = castlingPart.find('k') == std::string::npos;
    blackRookQueensideMoved_ = castlingPart.find('q') == std::string::npos;

    enPassantTarget_ = (epPart == "-") ? Square() : Square::fromString(epPart);

    try {
        halfmoveClock_ = std::stoi(halfmovePart);
        fullmoveNumber_ = std::stoi(fullmovePart);
    } catch (...) {
        halfmoveClock_ = 0;
        fullmoveNumber_ = 1;
    }

    history_.clear();
    return true;
}

} // namespace chess
