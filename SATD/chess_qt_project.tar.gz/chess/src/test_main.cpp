#include "Board.h"
#include <iostream>
#include <cassert>

using namespace chess;

static void printStatus(const Board& b) {
    GameStatus s = b.status();
    switch (s) {
        case GameStatus::InProgress: std::cout << "  [в игре]\n"; break;
        case GameStatus::Check: std::cout << "  [ШАХ]\n"; break;
        case GameStatus::Checkmate: std::cout << "  [МАТ]\n"; break;
        case GameStatus::Stalemate: std::cout << "  [ПАТ]\n"; break;
        case GameStatus::DrawByFiftyMoves: std::cout << "  [ничья: 50 ходов]\n"; break;
        case GameStatus::DrawByRepetition: std::cout << "  [ничья: повторение]\n"; break;
        case GameStatus::DrawByInsufficientMaterial: std::cout << "  [ничья: недостаточно материала]\n"; break;
    }
}

bool tryMove(Board& b, const std::string& from, const std::string& to,
             PieceType promo = PieceType::None) {
    bool ok = b.makeMove(Square::fromString(from), Square::fromString(to), promo);
    std::cout << from << "->" << to << (ok ? " OK" : " ОШИБКА: ход не разрешён") << "\n";
    return ok;
}

int main() {
    std::cout << "=== Тест 1: Детский мат (Scholar's mate) ===\n";
    {
        Board b;
        tryMove(b, "e2", "e4");
        tryMove(b, "e7", "e5");
        tryMove(b, "f1", "c4");
        tryMove(b, "b8", "c6");
        tryMove(b, "d1", "h5");
        tryMove(b, "g8", "f6"); // защита от мата, но не от всех угроз
        tryMove(b, "h5", "f7"); // Qxf7+ мат
        std::cout << b.toAscii();
        printStatus(b);
        assert(b.status() == GameStatus::Checkmate);
        std::cout << "Тест 1 пройден.\n\n";
    }

    std::cout << "=== Тест 2: Рокировка ===\n";
    {
        Board b;
        tryMove(b, "e2", "e4");
        tryMove(b, "e7", "e5");
        tryMove(b, "g1", "f3");
        tryMove(b, "g8", "f6");
        tryMove(b, "f1", "c4");
        tryMove(b, "f8", "c5");
        tryMove(b, "e1", "g1"); // короткая рокировка белых (флаг определяется автоматически)
        std::cout << b.toAscii();
        Piece king = b.at(Square::fromString("g1"));
        Piece rook = b.at(Square::fromString("f1"));
        assert(king.type == PieceType::King && king.color == Color::White);
        assert(rook.type == PieceType::Rook && rook.color == Color::White);
        std::cout << "Рокировка выполнена корректно.\n\n";
    }

    std::cout << "=== Тест 3: Взятие на проходе ===\n";
    {
        Board b;
        tryMove(b, "e2", "e4");
        tryMove(b, "a7", "a6");
        tryMove(b, "e4", "e5");
        tryMove(b, "d7", "d5"); // чёрная пешка идёт на 2 клетки рядом с белой пешкой на e5
        bool ok = tryMove(b, "e5", "d6"); // взятие на проходе (флаг определяется автоматически)
        assert(ok);
        Piece captured = b.at(Square::fromString("d5"));
        assert(captured.isEmpty()); // пешка должна быть взята
        std::cout << b.toAscii();
        std::cout << "Взятие на проходе работает корректно.\n\n";
    }

    std::cout << "=== Тест 4: Пат (Stalemate) ===\n";
    {
        Board b;
        // Классическая патовая позиция: чёрный король a8 в углу, белый король c6,
        // белый ферзь b6. У чёрного короля нет легальных ходов (все соседние клетки
        // либо заняты/под боем), но при этом сам король не атакован.
        bool ok = b.loadFEN("k7/8/1QK5/8/8/8/8/8 b - - 0 1");
        assert(ok);
        std::cout << b.toAscii();
        printStatus(b);
        assert(!b.isKingInCheck(Color::Black));
        assert(b.status() == GameStatus::Stalemate);
        std::cout << "Тест 4 (пат) пройден.\n\n";
    }

    std::cout << "=== Тест 5: Отмена хода (undo) ===\n";
    {
        Board b;
        std::string fenBefore = b.toFEN();
        tryMove(b, "e2", "e4");
        tryMove(b, "e7", "e5");
        b.undoMove();
        b.undoMove();
        std::string fenAfter = b.toFEN();
        assert(fenBefore == fenAfter);
        std::cout << "FEN до и после отмены совпадают: " << fenAfter << "\n";
        std::cout << "Тест 5 пройден.\n\n";
    }

    std::cout << "=== Тест 6: Превращение пешки ===\n";
    {
        Board b;
        tryMove(b, "a2", "a4");
        tryMove(b, "h7", "h6");
        tryMove(b, "a4", "a5");
        tryMove(b, "h6", "h5");
        tryMove(b, "a5", "a6");
        tryMove(b, "h5", "h4");
        tryMove(b, "a6", "b7"); // взятие пешки b7
        tryMove(b, "h4", "h3");
        bool ok = tryMove(b, "b7", "a8", PieceType::Queen); // превращение со взятием ладьи
        assert(ok);
        Piece promoted = b.at(Square::fromString("a8"));
        assert(promoted.type == PieceType::Queen && promoted.color == Color::White);
        std::cout << b.toAscii();
        std::cout << "Превращение пешки в королеву работает.\n\n";
    }

    std::cout << "ВСЕ ТЕСТЫ ПРОЙДЕНЫ УСПЕШНО\n";
    return 0;
}
