#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace chess {

// ----------------------------- Базовые типы -----------------------------

enum class Color : uint8_t {
    White = 0,
    Black = 1,
    None  = 2
};

inline Color opposite(Color c) {
    if (c == Color::White) return Color::Black;
    if (c == Color::Black) return Color::White;
    return Color::None;
}

enum class PieceType : uint8_t {
    None   = 0,
    Pawn   = 1,
    Knight = 2,
    Bishop = 3,
    Rook   = 4,
    Queen  = 5,
    King   = 6
};

struct Piece {
    PieceType type  = PieceType::None;
    Color     color = Color::None;

    Piece() = default;
    Piece(PieceType t, Color c) : type(t), color(c) {}

    bool isEmpty() const { return type == PieceType::None; }

    bool operator==(const Piece& other) const {
        return type == other.type && color == other.color;
    }
    bool operator!=(const Piece& other) const { return !(*this == other); }
};

// Координата на доске: file (столбец) 0..7 = a..h, rank (ряд) 0..7 = 1..8
struct Square {
    int file = -1; // 0..7  (a..h)
    int rank = -1; // 0..7  (1..8)

    Square() = default;
    Square(int f, int r) : file(f), rank(r) {}

    bool isValid() const {
        return file >= 0 && file < 8 && rank >= 0 && rank < 8;
    }

    bool operator==(const Square& o) const { return file == o.file && rank == o.rank; }
    bool operator!=(const Square& o) const { return !(*this == o); }

    // Алгебраическая нотация, например "e4"
    std::string toString() const {
        if (!isValid()) return "-";
        std::string s;
        s += static_cast<char>('a' + file);
        s += static_cast<char>('1' + rank);
        return s;
    }

    static Square fromString(const std::string& s) {
        if (s.size() != 2) return Square();
        int f = s[0] - 'a';
        int r = s[1] - '1';
        return Square(f, r);
    }

    // Удобный индекс 0..63 для использования в массивах/картах
    int index() const { return rank * 8 + file; }
    static Square fromIndex(int idx) { return Square(idx % 8, idx / 8); }
};

enum class MoveFlag : uint8_t {
    Normal        = 0,
    DoublePawn    = 1, // ход пешки на две клетки
    EnPassant     = 2, // взятие на проходе
    CastleKingside  = 3,
    CastleQueenside = 4,
    Promotion     = 5
};

struct Move {
    Square from;
    Square to;
    MoveFlag flag = MoveFlag::Normal;
    PieceType promotion = PieceType::None; // если flag == Promotion

    Move() = default;
    Move(Square f, Square t, MoveFlag fl = MoveFlag::Normal, PieceType promo = PieceType::None)
        : from(f), to(t), flag(fl), promotion(promo) {}

    bool operator==(const Move& o) const {
        return from == o.from && to == o.to && flag == o.flag && promotion == o.promotion;
    }
};

// Результат хода / состояние игры
enum class GameStatus : uint8_t {
    InProgress,
    Check,
    Checkmate,
    Stalemate,
    DrawByFiftyMoves,
    DrawByRepetition,
    DrawByInsufficientMaterial
};

// Запись о сделанном ходе — нужна для отмены (undo) и истории партии
struct MoveRecord {
    Move move;
    Piece movedPiece;
    Piece capturedPiece;     // фигура, которая была взята (если была)
    Square capturedSquare;   // клетка взятой фигуры (для en passant отличается от move.to)
    bool prevWhiteKingMoved = false;
    bool prevBlackKingMoved = false;
    bool prevWhiteRookKingsideMoved = false;
    bool prevWhiteRookQueensideMoved = false;
    bool prevBlackRookKingsideMoved = false;
    bool prevBlackRookQueensideMoved = false;
    Square prevEnPassantTarget;
    int prevHalfmoveClock = 0;
};

} // namespace chess
