#pragma once
#include <QWidget>
#include <QPixmap>
#include <QMap>
#include <optional>
#include "Board.h"

// ChessBoardWidget — виджет, который рисует шахматную доску и фигуры,
// обрабатывает клики мышью (выбор фигуры -> выбор клетки назначения),
// подсвечивает возможные ходы, последний сделанный ход и шах.
//
// Картинки фигур: положите 12 файлов в resources/pieces/ с именами вида
//   white_pawn.png, white_knight.png, white_bishop.png, white_rook.png,
//   white_queen.png, white_king.png,
//   black_pawn.png, black_knight.png, black_bishop.png, black_rook.png,
//   black_queen.png, black_king.png
// (подходят и .svg — Qt их тоже грузит через QPixmap/QIcon, либо легко
// переключить на QSvgRenderer, см. loadPieceImages()).
// Если картинки не найдены, виджет рисует фигуры простыми текстовыми
// символами (♔♕♖♗♘♙ и т.п.), так что приложение работает и без ресурсов.
class ChessBoardWidget : public QWidget {
    Q_OBJECT
public:
    explicit ChessBoardWidget(QWidget* parent = nullptr);

    // Полный доступ к текущей позиции (например, для сохранения/загрузки FEN)
    chess::Board& board() { return board_; }
    const chess::Board& board() const { return board_; }

    void newGame();
    bool undo();

    // Перевернуть доску (чтобы снизу были чёрные)
    void setFlipped(bool flipped);
    bool isFlipped() const { return flipped_; }

    QSize sizeHint() const override;

signals:
    // Испускается после каждого успешно сделанного хода
    void moveMade(const chess::Move& move);
    // Испускается, когда игра завершилась (мат/пат/ничья)
    void gameOver(chess::GameStatus status);
    // Текстовое сообщение для статус-бара (например "Ход белых", "Шах!")
    void statusMessage(const QString& text);

protected:
    void paintEvent(QPaintEvent* event) override;
    void mousePressEvent(QMouseEvent* event) override;
    void resizeEvent(QResizeEvent* event) override;

private:
    chess::Board board_;
    bool flipped_ = false; // false: белые внизу (стандартная ориентация)

    std::optional<chess::Square> selected_;          // выбранная клетка (откуда ходим)
    std::vector<chess::Move> selectedLegalMoves_;     // легальные ходы для выбранной фигуры
    std::optional<chess::Move> lastMove_;             // последний сделанный ход (для подсветки)

    QMap<QString, QPixmap> pieceImages_; // ключ вида "white_pawn"
    bool imagesLoaded_ = false;

    int squareSize_ = 64;
    int boardOriginX_ = 0;
    int boardOriginY_ = 0;

    void loadPieceImages();
    QString pieceImageKey(const chess::Piece& p) const;

    void recomputeGeometry();
    chess::Square widgetPosToSquare(QPoint pos) const;
    QPoint squareTopLeft(chess::Square sq) const;
    QRect squareRect(chess::Square sq) const;

    void handleSquareClicked(chess::Square sq);
    void tryMakeMove(chess::Square from, chess::Square to);
    void clearSelection();

    // Если ход — превращение пешки, спрашиваем пользователя, во что превращать
    chess::PieceType askPromotionChoice(chess::Color sideToMove);

    void emitStatusForCurrentPosition();

    void drawBoardSquares(class QPainter& painter);
    void drawCoordinates(class QPainter& painter);
    void drawHighlights(class QPainter& painter);
    void drawPieces(class QPainter& painter);
};
