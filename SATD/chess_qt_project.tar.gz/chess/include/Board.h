#pragma once
#include "ChessTypes.h"
#include <array>
#include <map>
#include <optional>

namespace chess {

// Класс Board хранит полное состояние шахматной партии и реализует
// все правила: генерацию ходов, проверку шаха/мата/пата, рокировку,
// взятие на проходе, превращение пешки, ничьи.
class Board {
public:
    Board();

    // Сброс в начальную позицию
    void reset();

    // ---- Доступ к состоянию ----
    Piece at(Square sq) const;
    Piece at(int file, int rank) const { return at(Square(file, rank)); }
    Color sideToMove() const { return sideToMove_; }
    int fullmoveNumber() const { return fullmoveNumber_; }
    int halfmoveClock() const { return halfmoveClock_; }
    Square enPassantTarget() const { return enPassantTarget_; }

    // ---- Генерация ходов ----
    // Все легальные ходы для текущей стороны (с учётом того, что после
    // хода свой король не должен оставаться под шахом)
    std::vector<Move> generateLegalMoves() const;
    // Легальные ходы для конкретной фигуры (для подсветки в GUI)
    std::vector<Move> legalMovesFrom(Square from) const;

    // Является ли ход легальным. Поиск идёт по from/to (и promotion, если указан) —
    // флаг (рокировка/en passant/double pawn) определяется автоматически,
    // вызывающему коду (GUI) не нужно знать о внутренних деталях.
    bool isMoveLegal(Square from, Square to, PieceType promotion = PieceType::None) const;
    // Перегрузка, принимающая готовый Move (флаг в нём может быть любым —
    // используются только from/to/promotion).
    bool isMoveLegal(const Move& m) const;

    // Находит полностью заполненный (с правильным flag) легальный ход по from/to,
    // либо возвращает std::nullopt, если такого легального хода нет.
    std::optional<Move> findLegalMove(Square from, Square to, PieceType promotion = PieceType::None) const;

    // ---- Выполнение ходов ----
    // Делает ход по клеткам from/to. Если это превращение пешки, нужно передать
    // promotion (тип фигуры, в которую превращается пешка), иначе по умолчанию — Queen.
    // Сам определяет, является ли ход рокировкой/взятием на проходе/превращением.
    // Возвращает false, если такого легального хода не существует.
    bool makeMove(Square from, Square to, PieceType promotion = PieceType::Queen);
    // Перегрузка для совместимости: использует from/to/promotion из переданного Move,
    // флаг определяется автоматически (значение m.flag игнорируется).
    bool makeMove(const Move& m);

    // Отмена последнего хода
    bool undoMove();

    // ---- Статус игры ----
    bool isKingInCheck(Color c) const;
    bool isCheckmate() const;   // мат текущей стороне, которой сейчас играть
    bool isStalemate() const;   // пат текущей стороне
    GameStatus status() const;

    // Текущая сторона не имеет легальных ходов?
    bool sideToMoveHasNoMoves() const;

    // История ходов (в виде записей для undo)
    const std::vector<MoveRecord>& history() const { return history_; }

    // Удобный метод: найти клетку короля нужного цвета
    Square kingSquare(Color c) const;

    // Под атакой ли клетка sq со стороны цвета attacker (используется и для
    // определения шаха, и для проверки рокировки/ходов короля)
    bool isSquareAttacked(Square sq, Color attacker) const;

    // Текстовое представление доски (для дебага в консоли)
    std::string toAscii() const;

    // Экспорт позиции в FEN (без полной валидации, но достаточно для отображения)
    std::string toFEN() const;

    // Загрузка позиции из FEN-строки. Возвращает false при некорректном FEN
    // (в этом случае состояние доски не определено — лучше пересоздать Board).
    bool loadFEN(const std::string& fen);

private:
    std::array<Piece, 64> squares_{};

    Color sideToMove_ = Color::White;

    // Права на рокировку
    bool whiteKingMoved_ = false;
    bool blackKingMoved_ = false;
    bool whiteRookKingsideMoved_ = false;
    bool whiteRookQueensideMoved_ = false;
    bool blackRookKingsideMoved_ = false;
    bool blackRookQueensideMoved_ = false;

    // Клетка, на которую возможно взятие на проходе в данный момент (или невалидна)
    Square enPassantTarget_;

    int halfmoveClock_ = 0;   // для правила 50 ходов
    int fullmoveNumber_ = 1;

    std::vector<MoveRecord> history_;

    // ---- Внутренние помощники ----
    Piece& pieceAt(Square sq) { return squares_[sq.index()]; }
    const Piece& pieceAt(Square sq) const { return squares_[sq.index()]; }

    void setPiece(Square sq, Piece p) { squares_[sq.index()] = p; }
    void clearSquare(Square sq) { squares_[sq.index()] = Piece(); }

    // Генерация псевдо-легальных ходов (без учёта того, что король может
    // остаться под шахом) — основа для generateLegalMoves
    std::vector<Move> generatePseudoLegalMoves(Color side) const;
    void generatePseudoLegalMovesForSquare(Square from, std::vector<Move>& out) const;

    void generatePawnMoves(Square from, std::vector<Move>& out) const;
    void generateKnightMoves(Square from, std::vector<Move>& out) const;
    void generateBishopMoves(Square from, std::vector<Move>& out) const;
    void generateRookMoves(Square from, std::vector<Move>& out) const;
    void generateQueenMoves(Square from, std::vector<Move>& out) const;
    void generateKingMoves(Square from, std::vector<Move>& out) const;

    void generateSlidingMoves(Square from, const std::vector<std::pair<int,int>>& directions,
                               std::vector<Move>& out) const;

    // Применяет ход "сырым" способом без проверок легальности (используется и
    // в makeMove, и временно внутри isMoveLegal для проверки на оставление короля под шахом)
    MoveRecord applyMoveInternal(const Move& m);
    void revertMoveInternal(const MoveRecord& rec);

    bool isPathClear(Square from, Square to) const; // для рокировки/диагоналей не используется напрямую
};

} // namespace chess
