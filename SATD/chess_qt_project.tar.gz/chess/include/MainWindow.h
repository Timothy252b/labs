#pragma once
#include <QMainWindow>
#include "ChessTypes.h"

class ChessBoardWidget;
class QListWidget;
class QLabel;
class QPushButton;
class QCheckBox;

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);

private slots:
    void onMoveMade(const chess::Move& move);
    void onGameOver(chess::GameStatus status);
    void onStatusMessage(const QString& text);
    void onNewGameClicked();
    void onUndoClicked();
    void onFlipClicked();

private:
    ChessBoardWidget* boardWidget_ = nullptr;
    QListWidget* moveListWidget_ = nullptr;
    QLabel* statusLabel_ = nullptr;
    QPushButton* newGameButton_ = nullptr;
    QPushButton* undoButton_ = nullptr;
    QPushButton* flipButton_ = nullptr;

    int moveCounterForDisplay_ = 0;

    void setupUi();
    QString moveToAlgebraic(const chess::Move& move) const;
};
